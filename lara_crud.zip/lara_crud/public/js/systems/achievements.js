class Achievements extends MainController
{
	constructor()
	{
		super();
	}

	process()
	{
		const mainConfig = this.mainConfig;
		const ajaxCall   = this.ajaxCall;

		$('#form_achievements').off('submit').on('submit',function(e){
			e.preventDefault();
			const data = $(this).serialize();

			const option = {
				url:mainConfig.baseUrl+'/process',
				data:data,
				dataType:'json',
				method:'post'
			}

			ajaxCall(option,function(result){
				alert(result.msg);
			});
		});
	}

}
class MainController
{
	constructor(){}

	get mainConfig()
	{
		return this.getMainConfig();
	}

	getMainConfig()
	{
		const data = {
			'baseUrl':'http://localhost:8000',
		}
		return data;
	}

	ajaxCall(options,callback)
	{
		const config 	= new MainController();
		let defaultUrl  = config.mainConfig.baseUrl;
		let data 		= {};

		$.ajaxSetup({
			headers:{
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});

		let defaultOption = {
			url:defaultUrl,
			data:data,
			dataType:'json',
			success:function(result)
			{
				callback(result);
			}
		}

		const mainOption = Object.assign(defaultOption,options);
		$.ajax(mainOption);
	}
}
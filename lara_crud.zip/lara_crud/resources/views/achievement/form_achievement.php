<!DOCTYPE html>
<html>
	<head>
		<title>Achievements</title>
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="http://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
		<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      	rel="stylesheet">
		<link rel="stylesheet" href="<?= url('/css/style_main.css')?>">
		<link rel="stylesheet" href="<?= url('/css/plugin/selectize.css')?>">

		<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  		crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		<script src="<?= url('/js/plugins/selectize.js')?>"></script>
		<script src="http://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
		<style>
			.nav{
				color:white!important;
			}
		</style>
		<!-- TOKEN -->
		<meta name="csrf-token" content="<?= csrf_token()?>">
	</head>

	<body>
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark" style="background-color: #32093d!important;">
			<a class="navbar-brand" href="#">Jovi</a>
		  	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
		    	<span class="navbar-toggler-icon"></span>
		  	</button>
		  <div class="collapse navbar-collapse" id="navbarText">
		    <ul class="navbar-nav mr-auto">
		      <li class="nav-item">
		        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
		      </li>
		      <li class="nav-item active">
		        <a class="nav-link" href="#">Achievements</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="#"></a>
		      </li>
		    </ul>
		    <span class="navbar-text">
		      Future Javascript Developer
		    </span>
		  </div>
		</nav>

		<div class="container-fluid">
			<div class="row">
				<div class="col-md-4">
					<div class="p-sm">
						<form id="form_achievements">
							<div class="form-group">
								<label for="achievement_name">achievement name</label>
								<input type="text" name="achievement_name" class="form-control" placeholder="enter achievement name">
							</div>
							<div class="form-group">
								<label for="achievement_type">achievement type</label>
								<select name="achievement_type" class="selectize">
									<option value="">Select achievement type</option>
									<option value="1">Educational</option>
									<option value="2">Physical</option>
									<option value="3">Mental</option>
								</select>
							</div>
							<button id="btn_save_achievement" class="btn btn-primary">Save</button>
						</form>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-10 p-l-md p-md">
					<table id="tbl_achievements" class="table table-striped table-bordered table-condensed" style="width:100%">
						<thead>
							<tr>
								<th>achievement name</th>
								<th>created by</th>
								<th>created date</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($obj_achievements as $achievement):?>
							<tr>
								<td><?= $achievement['name']?></td>
								<td><?= $achievement['achievement_type_id']?></td>
								<td><?= $achievement['created_date']?></td>
							</tr>
							<?php endforeach;?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</body>
</html>

<script src="http://localhost/lara_crud/public/js/main/MainController.js"></script>
<script src="http://localhost/lara_crud/public/js/systems/achievements.js"></script>

<script>
	const achievements = new Achievements();
	achievements.process();

	$('select').selectize();

	$('#tbl_achievements').DataTable();
</script>
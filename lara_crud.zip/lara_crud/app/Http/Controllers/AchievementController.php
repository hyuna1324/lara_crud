<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Achievement;
use Exception;

class AchievementController extends Controller
{
    //

    public function index()
    {
    	try
    	{
    		$data = array();

    		$achievements = Achievement::all()->toArray();
    		$data['obj_achievements'] = $achievements;

    		return view('achievement.form_achievement',$data);
    	}
    	catch(PDOException $e)
    	{
    		return  $e->getMessage();
    	}
    	catch(Exception $e)
    	{
    		return $e->getMessage();
    	}
    }

    public function process(request $params)
    {
    	try
    	{
    		$params = $params->input();

    		$achievement 						= new Achievement;
    		$achievement->name  				= $params['achievement_name'];
    		$achievement->achievement_type_id 	= $params['achievement_type'];
    		$achievement->created_by 			= 1;
    		$achievement->created_date 			= date('Y-m-d H:i:s');
    		$achievement->save();

    		$status = 'success';
    		$msg 	= 'data successfully saved.';
    	}
    	catch(PDOException $e)
    	{
    		$status = 'error';
    		$msg 	= $e->getMessage();
    	}
    	catch(Exception $e)
    	{
    		$status = 'error';
    		$msg 	= $e->getMessage();
    	}

    	echo json_encode([
    		'status' => $status,
    		'msg' 	=> $msg
    	]);
    }
}
